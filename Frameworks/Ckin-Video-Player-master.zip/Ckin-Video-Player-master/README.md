# ckin
<img src="ckin-video-player.png" alt="ckin video player">

An opensource <strong>lightweight</strong> HTML5 Video Player using Javascript (No jQuery).

If you find any bug, please report.

Demo : https://hunzaboy.github.io/Ckin-Video-Player/

Todo:
<strong>Add more Skins</strong>

